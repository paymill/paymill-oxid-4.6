<?php
$sMetadataVersion = '1.4';
$aModule = array(
    'id'           => 'paymill',
    'title'        => 'Paymill',
    'description'  => 'Paymill Payment',
    'thumbnail'    => 'logo.jpeg',
    'version'      => '1.4',
    'author'       => 'Paymill GmbH',
    'url'          => 'http://www.paymill.de',
    'email'        => 'support@paymill.de',
    'extend'       => array(
    ),
    'files' => array(
    ),
    'blocks' => array(
        
    )
);